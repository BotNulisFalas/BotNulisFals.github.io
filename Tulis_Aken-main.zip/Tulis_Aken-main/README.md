# Tulis_Aken
<p><b>Tulis Aken</b> Adalah Source Code Bot Nulis Berbasis Web Yang Di Bangun Menggunakan Bahasa Pemrogramman Php + Bootstrap, Source Ini Terinspirasi Dari Bot Nulis Tulisno Yang Juga Merupakan Salah Satu Source Bot Nulis, Kata Tulis Aken Berasal Dari Bahasa Cirebon Yang Dimana Berarti Menuliskan.</p>

![tulis_aken](https://user-images.githubusercontent.com/59213454/126797932-e04d2eb5-23b7-4445-b7b5-f25057b0d1d3.png)

